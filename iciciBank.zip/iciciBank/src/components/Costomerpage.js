import React from 'react'
import Logoutnav from './Logoutnav'
import { Link } from 'react-router-dom'
import  "../CSS/Customerpage.css"

const Costomerpage = () => {
  return (
    <div>
      <Logoutnav/>
      <div className='heading'><h1>BANKING OPRATIONS </h1></div> 
      <div className='container container border border-dark border border-4  '>
      
      <div class="row ">
    <div class="col-lg-6 border border-dark border-3 p-3 bg-danger "><Link className='link' to="/withdraw">Withdraw</Link></div>
    <div class="col-lg-6 border border-dark border-3 p-3 bg-warning "><Link className='link' to="/deposit">Deposite</Link></div>
    <div class="col-lg-6 border border-dark border-3 p-3 bg-info  "><Link className='link' to="/checkbal">Check Balance</Link></div>
    <div class="col-lg-6 border border-dark border-3 p-3 bg-success"> <Link className='link' to="/transfer">Transfer</Link></div>
    <div class="col-lg-12 border border-dark border-3 p-3 bg-light"> <Link className='link' to="/">Customer Deatails</Link></div>
  </div>
      </div>
    </div>
  )

  }

export default Costomerpage
