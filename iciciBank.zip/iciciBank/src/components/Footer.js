import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
    return (
        <div className='container-fluid bg-success text-light  mt-5'>
            <div className='row py-4'>
            <Link className="navbar-brand navfont text-light" to="/"><h1>ICICI BANK</h1></Link>
            </div>
            <div className='row mb-5 ms-3'>
                <div className='col-sm-12 col-md-3'>
                    <h3 className='mb-3'>About Us</h3>
                    <p className='lh-md'>A bank is a financial institution that is licensed to accept checking and savings deposits and make loans.</p>
                  
                </div>
                <div className='col-sm-12 col-md-3'>
                    <h3 className='mb-3'>Services</h3>
                    <ul className='p-0 m-0 list-unstyled'>
                        <li className='mb-3'><span className='text-primary me-2'><i class="fa-solid fa-angle-right"></i></span>Loan Facilities</li>
                        <li className='mb-3'><span className='text-primary me-2'><i class="fa-solid fa-angle-right"></i></span>Cheque payments.</li>
                        <li className='mb-3'><span className='text-primary me-2'><i class="fa-solid fa-angle-right"></i></span>Consultancy.</li>
                        <li className='mb-3'><span className='text-primary me-2'><i class="fa-solid fa-angle-right"></i></span>Funds remittance.</li>
                        <li className='mb-3'><span className='text-primary me-2'><i class="fa-solid fa-angle-right"></i></span>Lockers</li>
                    </ul>
                </div>
                <div className='col-sm-12 col-md-3'>
                    <h3 className='mb-3'>Contact Us</h3>
                    <ul className='p-0 m-0 list-unstyled'>
                        <li className='mb-3'><i class="fa-solid fa-location-dot text-light"></i><span className='ms-3'>Branch: ICICI Bank Pune,</span><span className='d-block ms-4'> Pune-411028</span> </li>
                        <li className='mb-3'><i class="fa-solid fa-envelope"></i><span className='ms-3 '>icicibank@gmail.com</span></li>
                        <li><i class="fa-solid fa-phone"></i><span className='ms-3'>0217-889977</span></li>
                    </ul>
                </div>
                <div className='col-sm-12 col-md-3'>
                    <h3 className='mb-3'>Follow Us</h3>
                    <ul className='p-0 m-0 list-unstyled d-flex'>
                        <li><Link><i class="fa-brands fa-facebook fs-2 text-white me-3"></i></Link></li>
                        <li><Link><i class="fa-brands fa-twitter fs-2 text-light me-3"></i></Link></li>
                        <li><Link><i class="fa-brands fa-instagram fs-2 text-light me-3"></i></Link></li>
                        <li><Link><i class="fa-brands fa-linkedin fs-2 text-light me-3"></i></Link></li>
                    </ul>
                </div>
            </div>
            <div>
                <div className='col'>
                    <hr></hr>
                    <h6 className='text-center py-4'>Copyright 2022 <span className='text-primary'>ICICI Bank.com</span> | All Rights Reserved.</h6>
                </div>
            </div>
        </div>
    )
}

export default Footer