import React from 'react'

const Rules = () => {
    return (
        <div>
           
                <h1 className="mb-5 text-center heading p-3">RULES AND TIMING</h1>
                <div className='rules  ms-5 me-5 row ' >
                
                  <p >
                  <h4>Do Not Overdraw Your Checking Account</h4><br></br>
                  <h4>Keep the Required Minimum Savings Balance</h4><br/>
                  <h4>Set up Alerts for Suspicious Activity.</h4><br/>
                  <h4>Build a Relationship with Your Bank.</h4><br/>
                  <h4>Smoking Not Allowed</h4><br/>
                  <h4>Lunch Timing 1.30pm to 2.00pm</h4>
                  </p>
                </div>
                </div>

                )
}

                export default Rules